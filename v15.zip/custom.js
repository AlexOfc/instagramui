$(document).on('ready', function() {
                                                
    var yDown = null;
    var movingTop = false;
    function getTouches(evt) {
    return evt.touches ||             // browser API
            evt.originalEvent.touches[0]; // jQuery
    }                                                     

    function handleTouchStart(evt) {
        const firstTouch = getTouches(evt);                                  
        yDown = firstTouch.clientY;                                      
    };                                                

    function handleTouchMove(evt) {
        if ( ! yDown ) {
            return;
        }                                   
        var yUp = evt.originalEvent.touches[0].clientY;

        var yDiff = yDown - yUp;

            if ( yDiff > 100 ) {
                movingTop = true;
                /* up swipe */ 
            } else {
                movingTop = false
            }                                       
    };
    var username;
    var avatar;
    var currentElement;
    var currentDot;
    var timeout;
    var loaded = false;
    $('.story.not-viewed').on('touchstart', function() {
        username = $(this).find('.story-user').text();
        avatar = $(this).find('img').attr('src');
        $(this).removeClass('not-viewed');
    });
    $('.story.not-viewed').on('click', function() {
        username = $(this).find('.story-user').text();
        avatar = $(this).find('img').attr('src');
        $(this).removeClass('not-viewed');
    });
    $('.story').on('touchstart', function() {
        console.log(loaded)
        if (loaded) {
            $('#adnboost-tab .tab-content .owl-dots .owl-dot').first().click();
        }
    });
    function timeOutFunc($element, timetotal) {
        timeout = setTimeout(function() {
                var nextOne = $element.next().find('span');
                nextOne.click();                  
        }, timetotal);
    }
    function clearTimeFunc() {
        clearTimeout(timeout);
    }
    function progress( timetotal, $element) {
        
        $element
            .find('span')
            .animate({ width: '100%' }, timetotal);
        timeOutFunc($element, timetotal);
    };
    var stop = false;
    var expandedPageInserted = false;
    $('body').on('DOMNodeInserted', '#expanded-page', function () {
        if (!expandedPageInserted) {
            setTimeout(function() {
                    setTimeout(function() {
                        console.log(1)               
                        if (!loaded) {
                            currentDot = $('#adnboost-tab .tab-content .owl-dots .owl-dot').first();
                            currentElement = $('#adnboost-tab .tab-content .owl-item').first().find('.content-item');
                            currentElement.addClass('current');
                            currentDot.addClass('current');
                            var userstory = $('#adnboost-tab .user-icon-tab .user-name .name-cont');
                            $('.user-icon-tab').prepend('<img src="'+avatar+'"/>');
                            userstory.text(username);
                            currentElement.find('.see-more').addClass('active');
                        }
                        loaded = true;
                        // if (!stop) {
                        //     progress(currentElement.attr('data-tab-duration') * 1000, currentDot);
                        // }
                        
                    }, 100);
                // $('#expanded-page .tab-content').owlCarousel({
                //     nav: true,  
                //     responsive: {
                //         1: {
                //             items: 1
                //         }
                //     }
                // });
            },
            100),
            expandedPageInserted = true;
        }      
    });
});
